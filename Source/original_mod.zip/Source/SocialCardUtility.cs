using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld.Planet;
using UnityEngine;
using Verse;
using Verse.Sound;
using RimWorld;
using HarmonyLib;

namespace election
{
	/*
	public static class SocialCardUtility
	{
		private static List<Precept_Role> cachedRoles = AccessTools.StaticFieldRefAccess<List<Precept_Role>>(AccessTools.Field(typeof(SocialCardUtility), "cachedRoles")).Invoke();
		public static void DrawPawnRole(Pawn pawn, Rect rect)
		{
			float num = 17f;
			Precept_Role currentRole = pawn.Ideo?.GetRole(pawn);
			Ideo primaryIdeo = Faction.OfPlayer.ideos.PrimaryIdeo;
			string label = ((currentRole != null) ? currentRole.LabelCap : ((string)"NoRoleAssigned".Translate()));
			if (currentRole != null)
			{
				float y = rect.y + rect.height / 2f - 16f;
				Rect outerRect = rect;
				outerRect.x = num;
				outerRect.y = y;
				outerRect.width = 32f;
				outerRect.height = 32f;
				GUI.color = currentRole.ideo.Color;
				Widgets.DrawTextureFitted(outerRect, currentRole.Icon, 1f);
				GUI.color = Color.white;
			}
			else
			{
				GUI.color = Color.gray;
			}
			Rect rect2 = new Rect(rect.x, rect.y + rect.height / 2f - 16f, rect.width, 32f);
			rect2.xMin = num;
			rect2.xMax = rect.width - 150f - 10f;
			num += 42f;
			Rect rect3 = rect;
			rect3.xMin = num;
			Text.Anchor = TextAnchor.MiddleLeft;
			Widgets.Label(rect3, label);
			Text.Anchor = TextAnchor.UpperLeft;
			GUI.color = Color.white;
			if (Mouse.IsOver(rect2))
			{
				string roleDesc = "RoleDesc".Translate().Resolve();
				if (currentRole != null)
				{
					roleDesc = roleDesc + "\n\n" + currentRole.LabelForPawn(pawn) + ": " + currentRole.GetTip();
				}
				Widgets.DrawHighlight(rect2);
				TooltipHandler.TipRegion(tip: new TipSignal(() => roleDesc, pawn.thingIDNumber * 39), rect: rect2);
			}
			if (pawn.IsFreeNonSlaveColonist)
			{
				bool flag = cachedRoles.Any();
				if (!flag)
				{
					GUI.color = Color.gray;
				}
				float y2 = rect3.y + rect3.height / 2f - 14f;
				Rect rect4 = new Rect(rect.width - 150f, y2, 115f, 28f);
				rect4.xMax = rect.width - 26f - 4f;
				if (Widgets.ButtonText(rect4, "ChooseRole".Translate() + "...", drawBackground: true, doMouseoverSound: true, flag))
				{
					List<FloatMenuOption> list = new List<FloatMenuOption>();
					if (currentRole != null)
					{
						list.Add(new FloatMenuOption("RemoveCurrentRole".Translate(), delegate
						{
							Find.WindowStack.Add(Dialog_MessageBox.CreateConfirmation("ChooseRoleConfirmUnassign".Translate(currentRole.Named("ROLE"), pawn.Named("PAWN")) + "\n\n" + "ChooseRoleConfirmAssignPostfix".Translate(), delegate
							{
								currentRole.Unassign(pawn, generateThoughts: true);
							}));
						}, Widgets.PlaceholderIconTex, Color.white));
					}
					
					Find.WindowStack.Add(new FloatMenu(list));
				}
				GUI.color = Color.white;
			}
			GUI.color = new Color(1f, 1f, 1f, 0.5f);
			Widgets.DrawLineHorizontal(0f, rect.yMax, rect.width);
			GUI.color = Color.white;
		}
	}
	*/
}
