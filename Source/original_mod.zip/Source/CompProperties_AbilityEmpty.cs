﻿using System;
using Verse;
using RimWorld;

namespace election
{
	// Token: 0x02000D47 RID: 3399
	public class CompProperties_AbilityEmpty : CompProperties_AbilityEffectWithDuration
	{
		// Token: 0x04002FD5 RID: 12245
		public HediffDef hediffDef;

		// Token: 0x04002FD6 RID: 12246
		public bool onlyBrain;

		// Token: 0x04002FD7 RID: 12247
		public bool applyToSelf;

		// Token: 0x04002FD8 RID: 12248
		public bool onlyApplyToSelf;

		// Token: 0x04002FD9 RID: 12249
		public bool applyToTarget = true;

		// Token: 0x04002FDA RID: 12250
		public bool replaceExisting;
	}
}
