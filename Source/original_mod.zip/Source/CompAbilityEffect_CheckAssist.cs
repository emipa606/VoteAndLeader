﻿using System;
using Verse;
using RimWorld;

namespace election
{
	public class CompAbilityEffect_CheckAssist : CompAbilityEffect_WithDuration
	{
		public new CompProperties_AbilityEmpty Props
		{
			get
			{
				return (CompProperties_AbilityEmpty)this.props;
			}
		}

		public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
		{
			base.Apply(target, dest);
			core.setAssist();
		}

		protected void ApplyInner(Pawn target, Pawn other)
		{
			if (target != null)
			{
				
			}
		}
	}
}
