﻿using System;
using System.Reflection;
using HarmonyLib;
using Verse;
using RimWorld;
using RimWorld.Planet;
using UnityEngine;
using System.Collections.Generic;

namespace election
{


    public class HarmonyPatches : Mod
    {

        public HarmonyPatches(ModContentPack content) : base(content)
        {
            var harmony = new Harmony("com.yayo.election");
            harmony.PatchAll(Assembly.GetExecutingAssembly());

        }

    }




    [HarmonyPatch(typeof(GenDefDatabase))]
    [HarmonyPatch("GetDef")]
    internal class patch_GenDefDatabase_GetDef
    {
        [HarmonyPostfix]
        private static bool Prefix(ref Def __result, Type defType, string defName, bool errorOnFail = true)
        {
            if(defType == typeof(RimWorld.PreceptDef) && defName == "RoleChange")
            {
                __result = null;
                return false;
            }
            return true;
        }
    }



    [HarmonyPatch(typeof(World))]
    [HarmonyPatch("ExposeData")]
    public class patch_World_exposeData
    {
        private static void Postfix(World __instance)
        {
            dataUtility.GetData().ExposeData();
        }
    }




    [HarmonyPatch(typeof(SocialCardUtility))]
    [HarmonyPatch("DrawPawnRoleSelection")]
    internal class patch_SocialCardUtility_DrawPawnRoleSelection
    {
        private static List<Precept_Role> cachedRoles = AccessTools.StaticFieldRefAccess<List<Precept_Role>>(AccessTools.Field(typeof(SocialCardUtility), "cachedRoles")).Invoke();

        [HarmonyPostfix]
        static bool Prefix(Pawn pawn, Rect rect, Vector2 ___RoleChangeButtonSize)
        {
            if (core.val_debugMode) return true;
            if (pawn == core.Leader) return false;
            if (pawn.Ideo.GetRole(pawn) == null) return false;

            if (!pawn.IsFreeNonSlaveColonist)
            {
                return false;
            }
            Precept_Role precept_Role = pawn.Ideo?.GetRole(pawn);
            Ideo primaryIdeo = Faction.OfPlayer.ideos.PrimaryIdeo;
            Precept_Ritual roleChangeRitual = (Precept_Ritual)(pawn.Ideo?.GetPrecept(PreceptDefOf.RoleChange));
            //TargetInfo ritualTarget = roleChangeRitual.targetFilter.BestTarget(pawn, TargetInfo.Invalid);
            bool flag = cachedRoles.Any() && pawn.Ideo != null;
            if (!flag)
            {
                GUI.color = Color.gray;
            }
            float y = rect.y + rect.height / 2f - 14f;
            Rect rect2 = new Rect(rect.width - 150f, y, ___RoleChangeButtonSize.x, ___RoleChangeButtonSize.y);
            rect2.xMax = rect.width - 26f - 4f;
            if (Widgets.ButtonText(rect2, "ChooseRole".Translate() + "...", drawBackground: true, doMouseoverSound: true, flag))
            {
                //if (ritualTarget.IsValid)
                if (true)
                {
                    List<FloatMenuOption> list = new List<FloatMenuOption>();
                    if (precept_Role != null)
                    {
                        list.Add(new FloatMenuOption("RemoveCurrentRole".Translate(), delegate
                        {
                            if (pawn.Ideo.GetRole(pawn) != null) pawn.Ideo.GetRole(pawn).Unassign(pawn, false);
                        }, Widgets.PlaceholderIconTex, Color.white));
                    }
                    //foreach (Precept_Role cachedRole in cachedRoles)
                    //{
                    //    Precept_Role newRole = cachedRole;
                    //    if (newRole != precept_Role && newRole.Active && newRole.RequirementsMet(pawn) && (!newRole.def.leaderRole || pawn.Ideo == primaryIdeo))
                    //    {
                    //        string label = newRole.LabelForPawn(pawn) + " (" + newRole.def.label + ")";
                    //        list.Add(new FloatMenuOption(label, delegate
                    //        {
                    //            Dialog_BeginRitual dialog_BeginRitual = (Dialog_BeginRitual)roleChangeRitual.GetRitualBeginWindow(ritualTarget, null, null, pawn, new Dictionary<string, Pawn> { { "role_changer", pawn } });
                    //            dialog_BeginRitual.SetRoleToChangeTo(newRole);
                    //            Find.WindowStack.Add(dialog_BeginRitual);
                    //        }, newRole.Icon, newRole.ideo.Color, MenuOptionPriority.Default, DrawTooltip)
                    //        {
                    //            orderInPriority = newRole.def.displayOrderInImpact
                    //        });
                    //    }
                    //    void DrawTooltip(Rect r)
                    //    {
                    //        TipSignal tip = new TipSignal(() => newRole.GetTip(), pawn.thingIDNumber * 39);
                    //        TooltipHandler.TipRegion(r, tip);
                    //    }
                    //}
                    //foreach (Precept_Role cachedRole2 in cachedRoles)
                    //{
                    //    if ((cachedRole2 != precept_Role && !cachedRole2.RequirementsMet(pawn)) || !cachedRole2.Active)
                    //    {
                    //        string text = cachedRole2.LabelForPawn(pawn) + " (" + cachedRole2.def.label + ")";
                    //        if (cachedRole2.ChosenPawnSingle() != null)
                    //        {
                    //            text = text + ": " + cachedRole2.ChosenPawnSingle().LabelShort;
                    //        }
                    //        else if (!cachedRole2.RequirementsMet(pawn))
                    //        {
                    //            text = text + ": " + cachedRole2.GetFirstUnmetRequirement(pawn).GetLabel(cachedRole2).CapitalizeFirst();
                    //        }
                    //        else if (!cachedRole2.Active && cachedRole2.def.activationBelieverCount > cachedRole2.ideo.ColonistBelieverCountCached)
                    //        {
                    //            text += ": " + "InactiveRoleRequiresMoreBelievers".Translate(cachedRole2.def.activationBelieverCount, cachedRole2.ideo.memberName, cachedRole2.ideo.ColonistBelieverCountCached).CapitalizeFirst();
                    //        }
                    //        list.Add(new FloatMenuOption(text, null, cachedRole2.Icon, cachedRole2.ideo.Color)
                    //        {
                    //            orderInPriority = cachedRole2.def.displayOrderInImpact
                    //        });
                    //    }
                    //}
                    Find.WindowStack.Add(new FloatMenu(list));
                }
                else
                {
                    Messages.Message("AbilityDisabledNoAltarIdeogramOrRitualsSpot".Translate(), pawn, MessageTypeDefOf.RejectInput);
                }
            }
            GUI.color = Color.white;


            return false;
        }
    }

    /*
    [HarmonyPatch(typeof(SocialCardUtility))]
    [HarmonyPatch("DrawPawnRole")]
    internal class patch_SocialCardUtility_DrawPawnRole
    {
        [HarmonyPostfix]
        static bool Prefix(CompReloadable __instance, Pawn pawn, Rect rect)
        {
            if (core.val_debugMode) return true;
            float num = 17f;
            Precept_Role currentRole = pawn.Ideo?.GetRole(pawn);
            Ideo primaryIdeo = Faction.OfPlayer.ideos.PrimaryIdeo;
            string label = ((currentRole != null) ? currentRole.LabelCap : ((string)"NoRoleAssigned".Translate()));
            if (currentRole != null)
            {
                float y = rect.y + rect.height / 2f - 16f;
                Rect outerRect = rect;
                outerRect.x = num;
                outerRect.y = y;
                outerRect.width = 32f;
                outerRect.height = 32f;
                GUI.color = currentRole.ideo.Color;
                Widgets.DrawTextureFitted(outerRect, currentRole.Icon, 1f);
                GUI.color = Color.white;
            }
            else
            {
                GUI.color = Color.gray;
            }
            Rect rect2 = new Rect(rect.x, rect.y + rect.height / 2f - 16f, rect.width, 32f);
            rect2.xMin = num;
            rect2.xMax = rect.width - 150f - 10f;
            num += 42f;
            Rect rect3 = rect;
            rect3.xMin = num;
            Text.Anchor = TextAnchor.MiddleLeft;
            Widgets.Label(rect3, label);
            Text.Anchor = TextAnchor.UpperLeft;
            GUI.color = Color.white;
            if (Mouse.IsOver(rect2))
            {
                string roleDesc = "RoleDesc".Translate().Resolve();
                if (currentRole != null)
                {
                    roleDesc = roleDesc + "\n\n" + currentRole.LabelForPawn(pawn) + ": " + currentRole.GetTip();
                }
                Widgets.DrawHighlight(rect2);
                TooltipHandler.TipRegion(tip: new TipSignal(() => roleDesc, pawn.thingIDNumber * 39), rect: rect2);
            }

            GUI.color = new Color(1f, 1f, 1f, 0.5f);
            Widgets.DrawLineHorizontal(0f, rect.yMax, rect.width);
            GUI.color = Color.white;

            return false;

        }
    }
    */





    /*

    [HarmonyPatch(typeof(Map))]
    [HarmonyPatch("ExposeData")]
    public class patch_map_exposeData
    {
        private static void Postfix(Map __instance)
        {
            dataUtility.GetData(__instance).ExposeData();
        }
    }

    [HarmonyPatch(typeof(World))]
    [HarmonyPatch("ExposeData")]
    public class patch_World_exposeData
    {
        private static void Postfix(World __instance)
        {
            dataUtility.GetData(__instance).ExposeData();
        }
    }
    */




    [HarmonyPatch(typeof(DefGenerator), "GenerateImpliedDefs_PreResolve")]
    public class Patch_DefGenerator_GenerateImpliedDefs_PreResolve
    {
        public static void Prefix()
        {
            //yayoCombat.patchDef1();
        }

    }


}
