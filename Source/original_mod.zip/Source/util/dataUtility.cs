﻿using RimWorld;
using System.Collections.Generic;
using System.Linq;
using Verse;
using RimWorld.Planet;

namespace election
{

    public static class dataUtility
    {
        static myData data;


        public static myData GetData()
        {
            if (data == null) data = new myData();
            data.setParent(Find.World);
            return data;
        }

    }

}
